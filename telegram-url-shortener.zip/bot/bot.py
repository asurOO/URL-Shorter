import os, requests
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from dotenv import load_dotenv

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
BASE_URL = os.getenv("BASE_URL")

async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Send /shorten <URL>")

async def shorten(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not ctx.args:
        return await update.message.reply_text("Use /shorten <URL>")
    url = ctx.args[0]
    res = requests.post(f"http://shortener:5000/shorten", json={"url": url})
    if res.ok:
        await update.message.reply_text(res.json()['short_url'])
    else:
        await update.message.reply_text("Shortening failed.")

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("shorten", shorten))
app.run_polling()

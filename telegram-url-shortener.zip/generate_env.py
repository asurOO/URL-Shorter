import os

print("🛠️ URL Shortener Setup - .env Generator")

bot_token = input("🔐 Enter your Telegram Bot Token: ").strip()
base_url = input("🌐 Enter your base domain (e.g., https://usage.rtxconfigz.com): ").strip()

env_content = f"""BOT_TOKEN={bot_token}
BASE_URL={base_url}
"""

with open(".env", "w") as f:
    f.write(env_content)

print("\n✅ .env file created successfully!")

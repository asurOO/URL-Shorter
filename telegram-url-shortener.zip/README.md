# Telegram URL Shortener with NGINX + TLS

This project implements a Flask-based URL shortener integrated with a Telegram bot that generates short URLs like:

```
https://usage.rtxconfigz.com/<unique_id>
```

## Setup Instructions

1. Clone the repo:
   ```
   git clone <repo-url>
   cd telegram-url-shortener
   ```

2. Generate your `.env` file:
   ```
   python3 generate_env.py
   ```

3. Run docker compose:
   ```
   docker-compose up --build -d
   ```

4. Setup TLS certificates on your VPS for your domain using certbot:
   ```
   sudo apt install certbot
   sudo certbot certonly --webroot -w /var/www/certbot -d usage.rtxconfigz.com
   ```

5. Restart NGINX container:
   ```
   docker-compose restart nginx
   ```

## License

This project is licensed under GPLv3.
